<?php
session_start();
if( $_SESSION['visiteur']='user')
{
?>

    <!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Accueil User</title>
    <link rel="stylesheet" href="css.css">
</head>

<body>
    <h1>Bienvenue My User</h1><br> <br>
    <div id="div">

        <p>Login: User</p>
        <p>
            <a href="admin.php">Déconnection</a></p>


    </div>
    <a href="tableau00.php">Tableau en couleur;  </a>
    <a href="calcule.php">Calculatrice.</a>

</body>

</html>
<?php
}
else
{
    header('location:error.html');
}
?>